package com.example.agendaproject.model;

public enum Status {
    DISPONIVEL, INDISPONIVEL, EMPRESTADO;
}
